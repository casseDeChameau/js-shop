//empty
function empty(node) {
    while (node.children.length > 0) {
        node.removeChild(node.children[0]);
    }
}

//btns pagination
function updateHTML(event) {
    let offset = Number(event.currentTarget.dataset.offset);
    afficheArticle(offset);
}

//afficheArticle
function afficheArticle(offset) {
    empty(monMain);
    const articleParPage = 4;
    let nombreDePages = Math.ceil(apiUrl.length / articleParPage);

    let start = offset * articleParPage;
    let end = (start + articleParPage > apiUrl.length) ? apiUrl.length : start + articleParPage;

    // affiche les produits
    for (let i = start; i < end; i++) {
        let monArticle = document.createElement('ARTICLE');
        let products = dataJson.result;

        monArticle.innerHTML = `
                <h2>${products[i].name}</h2>
                <p>${products[i].description}</p>
                <p>category : ${products[i].category}</p>
                <p class="prix">${products[i].price} € </p>
                <img src="img/${products[i].id}.jpg">
                <button data-id="${products[i].id}" class="buy-btn">BUY it</button>
            `;
        monMain.appendChild(monArticle); 
        /* monMain.querySelector("ARTICLE:nth-of-type(" + (i+1-start)+ ") .buy-btn" ).addEventListener('click', function(){
            console.log('btnbuy' + this.dataset.id, this, this.dataset)
        }); */
    }

    let tempBtns = document.querySelectorAll('.buy-btn');
    let tempArrayBtns = Array.from(tempBtns);
    tempArrayBtns.forEach(item => item.addEventListener('click', function(event){
        let idAchat = Number(event.currentTarget.dataset.id);
        let indexAchat = panier.findIndex(item => item.id == idAchat);
        if (indexAchat != -1) {
            panier[indexAchat].quantity++;
        } else {
            panier.push({
                id: idAchat,
                quantity: 1
            })
        }
        console.log(panier);
        afficherPanier();
    }));
        
    // paging btn offset
    for (let i = 0; i < nombreDePages; i++) {
        let monBouton = document.createElement('BUTTON');
        monBouton.textContent = i + 1;
        monBouton.dataset.offset = i;
        if (offset == i) monBouton.disabled = true;
        monBouton.addEventListener('click', updateHTML)
        monMain.appendChild(monBouton);
    }
}

//mettreAJourQuantite
function mettreAJourQuantite(event){
    let indexAModifier = Number(event.currentTarget.dataset.indexamodifier);
    panier[indexAModifier].quantity = event.currentTarget.value;
    //console.log(panier)
    afficherPanier();
}

//supprimerDuPanier
function supprimerDuPanier(event){
    let indexASupprimer = Number(event.currentTarget.dataset.indexasupprimer);
    panier.splice(indexASupprimer, 1);
    afficherPanier();
}

//afficherPanier
function afficherPanier(){
    divPanier.innerHTML = '';
    let prixTotal = 0;
    //item se represente ainsi
    // {
    //   id: idAchat,
    //   quantity: 1
    // }
    panier.forEach((item, index)=>{
        // P container
        let tempP = document.createElement('P');
        let products = dataJson.result;
        let indexAchat = products.findIndex(produit => produit.id == item.id); 
        // Nom + Prix
        tempP.textContent = products[indexAchat].name + ' ' + products[indexAchat].price + '€';
        // Quantité
        let tempInput = document.createElement('INPUT');
        tempInput.setAttribute('type', 'number');
        tempInput.setAttribute('min', '1');
        tempInput.value = item.quantity;
        tempInput.dataset.indexamodifier = index;
        
        tempInput.addEventListener('input', mettreAJourQuantite);
        tempP.appendChild(tempInput);
        
        // Suppression
        let tempBtnSupprimer = document.createElement('BUTTON');
        tempBtnSupprimer.textContent = 'Supprimer';
        tempBtnSupprimer.dataset.indexasupprimer = index;
        tempBtnSupprimer.addEventListener('click', supprimerDuPanier);
        tempP.appendChild(tempBtnSupprimer);
        divPanier.appendChild(tempP);
        prixTotal += products[indexAchat].price * item.quantity;
        //prixTotal += prixTotal.toFixed(2);
    });
    // ToDo Button Confirm --> call ajax vers ogone/back/login
    let tempP = document.createElement('p');
    tempP.textContent = 'Total : ' + prixTotal + '€';
    divPanier.appendChild(tempP);
    //console.log('temps', n - Date.now());
}





// close shopping-list
let panierLink = document.querySelector('.panier');
let close = document.querySelector('.close');
panierLink.addEventListener('click', function(){
    panierList.classList.add('closed');
});
close.addEventListener('click', function(){
    panierList.classList.remove('closed');
});