function myInclude(file) { 
    var script = document.createElement('script'); 
    script.src = file; 
    script.defer = true; 
    document.getElementsByTagName('head').item(0).appendChild(script); 
}
myInclude("js/main_functions.js");


let monMain = document.querySelector('main');
let btnSearch = document.querySelector('button');
let panierList = document.querySelector('.panier-list');
let divPanier =  document.querySelector('#panier');
let panier = [];


//let monJSON = "http://localhost:8888/sites/shop-ajax/api.php";
const apiUrl = './api.php';
let dataJson;

document.addEventListener('DOMContentLoaded', function () {
    let xhr = new XMLHttpRequest();

    btnSearch.addEventListener('click', function (e) {
        e.preventDefault();
        xhr.addEventListener('readystatechange', function (e) {
            if (this.readyState == 4 && this.status == 200) {
                dataJson = JSON.parse(this.responseText);
                afficheArticle(0);
            }
        });
        let monForm = document.querySelector('form');
        var params = new FormData(monForm); //<form></form>
        xhr.open('POST', apiUrl, true);
        xhr.send(params);

        //xhr.open('POST', apiUrl, true);
        //xhr.send();


        //xhr.open('POST', apiUrl, true);
        //xhr.send();

    });

}); 



