let items, resultsDiv, categories = [], categoriesSelect, sortSelect, orderSelect, basket = [], initialPricesFilter, pricesFilter, nameFilter, inBasket, priceSlider, pochetMoney = 100, basketPrice = 0, pochetMoneyP, basketPriceP, remainingP;
let curIntl = new Intl.NumberFormat('fr-BE', { style: 'currency', currency: 'EUR' });

window.addEventListener('load', function() {
	// Initialise global vars
	//-----------------------
	categoriesSelect = document.getElementById("categories");
	sortSelect = document.getElementById("Sorting");
	orderSelect = document.getElementById("Order");
	nameFilter = document.getElementById("Name");
	priceSlider = $("#slider");
	inBasketBtn = document.getElementById("BasketBtn");
	pochetMoneyP = document.getElementById("PochetMoney");
	basketPriceP = document.getElementById("BasketPrice");
	remainingP = document.getElementById("Remaining");
	//-----
	resultsDiv = document.getElementById("results");

	// Load JSON and feed the results
	//-------------------------------
	let ajax = new XMLHttpRequest();
	ajax.addEventListener('readystatechange', function () {
		if (this.status == 200 && this.readyState == 4) {
			items = Array.from(JSON.parse(this.responseText).result);
			items.forEach((elem, i) => {
				if (!categories.includes(elem.category)) {
					categories.push(elem.category);
					//-----
					var curCategory = document.createElement("option");
					curCategory.text = elem.category;
					categoriesSelect.appendChild(curCategory); 
				}
			});
			//-----
			SetPricesRange();
			FeedResultsDiv();
			AdaptScreenMoney();
		}
	});
	ajax.open("GET", "http://localhost/testjs/api.php", true);
	ajax.send();

	// Events
	//-------
	categoriesSelect.addEventListener('change', function () { FilterResults(); });
	sortSelect.addEventListener('change', function () { SortResults(); });
	orderSelect.addEventListener('change', function () { SortResults(); });
	nameFilter.addEventListener('keyup', function () { FilterResults(); });
	inBasketBtn.addEventListener('click', function () {
		inBasketBtn.classList.toggle('pressed');
		FilterResults();
	});
	document.getElementById("ResetBtn").addEventListener('click', function () { ResetFilters(); });
});

// Screen initialisation functions
//================================
{
	function FeedResultsDiv() {
		items.forEach((elem, i) => {
			let curItemDiv = document.createElement('article');
			curItemDiv.id = "item_" + elem.id;
			curItemDiv.classList.add("item");
			curItemDiv.innerHTML =
				'<div class="itemWrapper">' +
				'	<img src="img/' + elem.id + '.jpg">' +
				'	<div class="dataWrapper">' +
				'		<p><strong>Title:</strong> <span class="item_name">' + elem.name + '</span></p>' +
				'		<span>' +
				'			<p><strong>Id:</strong> ' + elem.id + '</p>' +
				'			<p><strong>Type:</strong> ' + elem.category + '</p>' +
				'			<p><strong>Price:</strong> ' + curIntl.format(elem.price) + '</p>' +
				'		</span>' +
				'		<p><strong>Description:</strong> ' + elem.description + '</p>' +
				'	</div>' +
				'	<div class="optionsWrapper">' +
				'		<p>In basket: <span id="basket_' + elem.id + '">0</span></p>' +
				'		<div id="optionsButtonsWrapper">' +
				'			<button id="BuyBtn_' + elem.id + '">+</button>' +
				'			<button id="RemoveBtn_' + elem.id + '">-</button>' +
				'		</div>';
				'	</div>';
			'</div>';
			resultsDiv.appendChild(curItemDiv);
			//-----
			document.getElementById("BuyBtn_" + elem.id).addEventListener('click', function () { BasketModifyItemCount(elem, 1); });
			document.getElementById("RemoveBtn_" + elem.id).addEventListener('click', function () { BasketModifyItemCount(elem, -1); });
		});
	}
	function ResetFilters() {
		categoriesSelect[0].selected = true;
		priceSlider.slider("values", [initialPricesFilter[0], initialPricesFilter[1]]);
		nameFilter.value = '';
		sortSelect[0].selected = true;
		orderSelect[0].selected = true;
		//-----
		SortResults();
		FilterResults();
	}
	function SetPricesRange() {
		let minPrice = 9999, maxPrice = 0;
		items.forEach((elem, i) => {
			elemPrice = parseFloat(elem.price);
			if (elemPrice > maxPrice) maxPrice = Math.ceil(elemPrice);
			if (elemPrice < minPrice) minPrice = Math.floor(elemPrice);
		});
		initialPricesFilter = pricesFilter = [minPrice, maxPrice];
		//-----
		priceSlider.slider({ range: true, min: minPrice, max: maxPrice, values: [minPrice, maxPrice], step: 1 });
		UpdatePricesRange(minPrice, maxPrice);
		//-----
		priceSlider.on("slidechange", function (event, ui) { UpdatePricesRange(ui.values[0], ui.values[1]); });
		priceSlider.on("slide", function (event, ui) {
			UpdatePricesRange(ui.values[0], ui.values[1]);
			FilterResults();
		});
	}
	function UpdatePricesRange(min, max) {
		pricesFilter = [min, max];
		$("#slider span:nth-of-type(1)").text(curIntl.format(min));
		$("#slider span:nth-of-type(2)").text(curIntl.format(max));
	}
	function AdaptScreenMoney() {
		// Adapt screen display
		//---------------------
		pochetMoneyP.innerText = curIntl.format(pochetMoney);
		basketPriceP.innerText = curIntl.format(basketPrice);
		remainingP.innerText = curIntl.format(pochetMoney - basketPrice);

		// Enable/disable buttons, if needed
		//----------------------------------
		items.forEach((elem, i) => {
			let curBasketItem = BasketItem(elem.id);
			document.getElementById("BuyBtn_" + elem.id).classList.toggle('disabled', basketPrice + Number(elem.price) > pochetMoney || curBasketItem.tobuy >= 10);
			document.getElementById("RemoveBtn_" + elem.id).classList.toggle('disabled', curBasketItem.tobuy <= 0);
		});
	}
}

// Filtering / sorting
//====================
{
	function FilterResults() {
		let visibleItemCnt = 0;
		items.forEach((elem, i) => {
			// Determine each filtering cases for this item
			//---------------------------------------------
			let outOfWantedCategory = (categoriesSelect.value != "All" && elem.category != categoriesSelect.value);
			let outOfWantedPrice = (elem.price < pricesFilter[0] || elem.price > pricesFilter[1]);
			let wordSearchedPos = (nameFilter.value == "" ? -1 : elem.name.toLowerCase().indexOf(nameFilter.value.toLowerCase()));
			let wordNotFound = (nameFilter.value != "" && wordSearchedPos < 0);
			let basketFiltered = (inBasketBtn.classList.contains('pressed') && BasketItem(elem.id).tobuy <= 0);

			// Hide or show this item
			//-----------------------
			let hideItem = (outOfWantedCategory || outOfWantedPrice || wordNotFound || basketFiltered);
			document.getElementById('item_' + elem.id).classList.toggle("hidden", hideItem);
			visibleItemCnt += (hideItem ? 0 : 1);

			// Highlight (or not) the searched word
			//-------------------------------------
			let nameToModify = document.querySelector('#item_' + elem.id + ' .item_name');
			wordSearchedPos = (wordSearchedPos >= 0 ? wordSearchedPos : elem.name.length);
			nameToModify.innerHTML =
				elem.name.substr(0, wordSearchedPos) +
				'<span style="background-color: red; color: white;">' + elem.name.substr(wordSearchedPos, nameFilter.value.length) + '</span>' +
				elem.name.substr(wordSearchedPos + nameFilter.value.length);
		});

		// Hide or show special messages
		//------------------------------
		document.querySelector('#badFilter').style.display = ((visibleItemCnt <= 0 && !inBasketBtn.classList.contains('pressed')) ? 'inline' : 'none');
		document.querySelector('#emptyBasket').style.display = ((visibleItemCnt <= 0 && inBasketBtn.classList.contains('pressed')) ? 'inline' : 'none');
	}
	function SortResults() {
		items.sort(function(a, b) {
			let compRes = 0;
			switch (sortSelect.value) {
				case 'name': compRes = a.name.localeCompare(b.name); break;
				case 'id': compRes = a.id - b.id; break;
				case 'price': {
					compRes = a.price - b.price;
					if (compRes == 0)
						compRes = a.name.localeCompare(b.name);
					break
				};
			}
			return compRes * (orderSelect.value == 'asc' ? 1 : -1);
		});
		//-----
		items.forEach((elem, i) => { document.getElementById('item_' + elem.id).style.order = i; });
	}
}

// Basket access
//==============
{
	function BasketModifyItemCount(item, countDelta) {
		let curBasketItem = BasketItem(item.id), origBasketItemCnt = curBasketItem.tobuy;
		document.getElementById("basket_" + item.id).innerHTML = (curBasketItem.tobuy += countDelta);
		//-----
		basketPrice += item.price * (curBasketItem.tobuy - origBasketItemCnt);
		basketPrice = Math.round(basketPrice * 100) / 100;
		AdaptScreenMoney();

		// Refresh the results, if needed
		//-------------------------------
		if (curBasketItem.tobuy <= 0 && inBasketBtn.classList.contains('pressed'))
			FilterResults();
	}
	function BasketItem(itemId) {
		for (let i = 0; i < basket.length; i++) {
			if (basket[i].id == itemId)
				return basket[i];
		}
		//-----
		let newItem = { "id": itemId, "tobuy": 0 };
		return basket[basket.push(newItem) - 1];
	}
}
