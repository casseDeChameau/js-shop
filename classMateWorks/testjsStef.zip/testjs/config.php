<?php
define ('DB_HOST', 'localhost');        // Le serveur
define ('DB_USER', 'root');             // L'utilisateur (sous-entendu le script PHP)
define ('DB_PWD' , '');                 // Le mot de passe
define ('DB_NAME', 'shop');             // La DB
define ('MYSQL_DSN', 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8'); 
?>
