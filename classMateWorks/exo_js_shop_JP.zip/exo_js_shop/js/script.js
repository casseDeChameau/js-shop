//Panier Flap

let panierBtn = document.querySelector('#menu-panier');
let panierFlap = document.querySelector('.panier-volet');
let closeBtn = document.querySelector('.close');


panierBtn.addEventListener('click', function(){
    panierFlap.classList.add('closed');  
});

closeBtn.addEventListener('click', function(){
    panierFlap.classList.remove('closed');
});


// CALL AJAX

// const URLAPI = './api.php';
let xhr = new XMLHttpRequest(); 
let dataJson;

xhr.addEventListener('readystatechange', function(e){

    if (this.readyState == 4 && this.status == 200) {
        dataJson = JSON.parse(this.responseText);

        let divWrapper = document.querySelector('.wrapper');
        
        for (let i = 0; i < dataJson.result.length; i++) {
            let monArticle = document.createElement ('article');
            monArticle.innerHTML = 
            `<div class="article">
                <div class="article-img">
                    <img src="img/${dataJson.result[i].id}.jpg" alt="">
                </div>
                <div class="article-txt">
                    <div class="first-info">
                        <h2 class="name">${dataJson.result[i].name}</h2> <span>|</span>
                        <p class="price">Prix:${dataJson.result[i].price}€</p>
                    </div>
                    <p class="description">${dataJson.result[i].description}</p>
                    <div class="btn-commander"><button>Commander</button></div>
                </div>`;
            divWrapper.appendChild(monArticle);
        }
        let myBtnBuy = document.querySelectorAll('.wrapper button')
        for (let i = 0; i < myBtnBuy.length; i++) {
            myBtnBuy[i].addEventListener('click', function(e){
                console.log (e.currentTarget.dataset.id)
            })
        }
    }
})
xhr.open("GET", "./api.php", true);
xhr.send();


// PAGER 

// function empty(node) {
//     while(node.children.length > 0) {
//         node.removeChild(node.children[0]);
//     }
// }

// // ...
// function updateHTML(event) {
//     let offset = Number(event.currentTarget.dataset.offset);
    
//     afficheArticle(offset);
// }

// let monJSON = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M'];
// let monMain = document.querySelector('main');

// function afficheArticle(offset) {
//     empty(monMain);
    
//     const articleParPage = 4;
//     let nombreDePages = Math.ceil(monJSON.length / articleParPage);
    
//     let start = offset * articleParPage;
//     let end = (start + articleParPage > monJSON.length) ? monJSON.length : start + articleParPage;
// //            if (start + articleParPage > monJSON.length) {
// //                let end = monJSON.length;
// //            } else {
// //                let end = start + articleParPage;
// //            }
    
//     // affiche les articles
//     for (let i = start; i < end; i++) {
//         let monArticle = document.createElement('ARTICLE');
//         monArticle.textContent = 'N°' + String(i + 1) + ' ' + monJSON[i];

//         monMain.appendChild(monArticle);
//     }

//     // affiche le pager
//     for (let i = 0; i < nombreDePages; i++) {
//         let monBouton = document.createElement('BUTTON');
//         monBouton.textContent = i + 1;
//         monBouton.dataset.offset = i;
        
//         if (offset == i) {
//             monBouton.disabled = true;
//         }
        
//         monBouton.addEventListener('click', updateHTML)
        
//         monMain.appendChild(monBouton);
//     }
// }

// afficheArticle(0);
